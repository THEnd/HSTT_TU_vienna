package com.petpet.c3po.gatherer;


public class RosettaGatherer {
}
