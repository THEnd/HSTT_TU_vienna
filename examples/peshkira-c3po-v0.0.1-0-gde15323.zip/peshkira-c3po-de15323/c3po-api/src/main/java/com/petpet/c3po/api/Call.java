package com.petpet.c3po.api;

public interface Call {

  void back(Message<? extends Object> n);
}
