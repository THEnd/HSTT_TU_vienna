package com.petpet.c3po.command;

public interface Command {

  void execute();

  long getTime();
}
