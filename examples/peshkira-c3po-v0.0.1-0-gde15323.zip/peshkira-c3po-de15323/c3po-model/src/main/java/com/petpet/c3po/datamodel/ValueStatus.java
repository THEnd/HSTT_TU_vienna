package com.petpet.c3po.datamodel;

public enum ValueStatus {
    OK, SINGLE_RESULT, CONFLICT
}
